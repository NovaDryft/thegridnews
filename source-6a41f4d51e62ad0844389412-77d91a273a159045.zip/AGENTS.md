# AGENTS.md — The Grid

This document provides an overview of the project structure for developers and AI agents working on this codebase.

## Project Overview

The Grid is a Matrix-themed real-time intelligence dashboard. It shows live weather, stock market data, and news headlines in a green neon aesthetic with an animated Matrix rain background. Data refreshes every 10 seconds automatically.

### Tech Stack

| Layer | Technology |
|-------|------------|
| Framework | TanStack Start |
| Frontend | React 19, TanStack Router v1 |
| Build | Vite 7 |
| Styling | Custom CSS (Matrix/neon theme) |
| Language | TypeScript 5 |
| Deployment | Netlify |

## Directory Structure

```
src/
  routes/
    __root.tsx        # HTML shell — page title, global styles import
    index.tsx         # All dashboard UI: MatrixRain, WeatherWidget, StocksWidget, NewsWidget, StockTicker
    api/
      weather.ts      # GET /api/weather — proxies Open-Meteo (free, keyless)
      news.ts         # GET /api/news    — parses BBC + Reuters RSS XML server-side
      stocks.ts       # GET /api/stocks  — proxies Yahoo Finance v8 chart API
  styles.css          # All styles — Matrix theme, animations, layout
  router.tsx          # TanStack router setup
public/
  favicon.ico
```

## Key Concepts

### API Routes
All three data sources are server-side API routes (`server.handlers` pattern). This avoids CORS and keeps third-party calls off the client.

- `/api/weather` — Open-Meteo, no key. Default location: New York City (lat/lon params supported).
- `/api/stocks` — Yahoo Finance `/v8/finance/chart/{symbol}`. Falls back to seeded prices if the endpoint is rate-limited.
- `/api/news` — BBC + Reuters RSS feeds parsed with regex. Returns up to 10 articles with a static 5-item fallback.

### Auto-Refresh
`TheGrid` (top-level component in `index.tsx`) owns all state and runs a single `setInterval` countdown from 10→0. At 0 it calls `fetchAll()` (Promise.allSettled over all 3 APIs) and resets.

### CSS Architecture
All styling is plain CSS in `styles.css`. No Tailwind utility classes in component JSX. Key design tokens:
- Primary neon green: `#00ff41` with `text-shadow: 0 0 14px #00ff41`
- Background: `#000` with `rgba(0,8,0,0.88)` panel backgrounds
- Scanline overlay: `::before` pseudo-element with `repeating-linear-gradient` on `.grid-app`
- Matrix rain: HTML Canvas, 50ms interval, katakana + ASCII charset

### Layout
`.grid-main` — CSS Grid `320px 1fr 1fr`. Responsive breakpoints at 1100px (2-col) and 640px (1-col).

## Conventions
- No comments; self-documenting names
- All state in `TheGrid`; child widgets are pure display props
- TypeScript interfaces at top of `index.tsx`
- API routes always return a fallback — never throw a 500 in production
