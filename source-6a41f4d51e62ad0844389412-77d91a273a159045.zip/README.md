# The Grid

A green neon Matrix-themed real-time intelligence dashboard built with TanStack Start and deployed on Netlify.

## What It Does

The Grid displays live data across three panels that auto-refresh every 10 seconds:

- **Atmospheric Conditions** — current weather (temperature, feels-like, humidity, wind) powered by the free [Open-Meteo](https://open-meteo.com/) API for New York City
- **Market Matrix** — live stock/crypto prices and daily change for 10 symbols (AAPL, MSFT, GOOGL, AMZN, NVDA, TSLA, META, BTC, ETH, SPY) via Yahoo Finance
- **Global Intel Feed** — top news headlines fetched from BBC and Reuters RSS feeds
- **Live Ticker** — scrolling stock ticker across the top of the page

All data is fetched server-side through TanStack Start API routes, so no API keys are required for any data source.

## Tech Stack

- **Framework**: [TanStack Start](https://tanstack.com/start) (React + Vite)
- **Styling**: Custom CSS (no Tailwind used in component styles)
- **Animations**: HTML Canvas Matrix rain effect, CSS scanlines overlay
- **Data**: Open-Meteo (weather), Yahoo Finance v8 (stocks), BBC/Reuters RSS (news)
- **Deploy**: Netlify

## Running Locally

```bash
npm install
npm run dev
```

The app runs on `http://localhost:3000` by default, or use the Netlify CLI for full platform emulation:

```bash
netlify dev --port 8889
```

No environment variables are required — all data sources are free and keyless.
