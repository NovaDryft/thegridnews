import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/api/news')({
  server: {
    handlers: {
      GET: async () => {
        try {
          const feeds = [
            { url: 'https://feeds.bbci.co.uk/news/world/rss.xml', source: 'BBC' },
            { url: 'https://rss.reuters.com/reuters/topNews', source: 'REUTERS' },
          ]

          const results: Array<{ title: string; source: string; link: string; pubDate: string }> = []

          for (const feed of feeds) {
            try {
              const resp = await fetch(feed.url, {
                headers: { 'User-Agent': 'TheGrid/1.0' },
                signal: AbortSignal.timeout(5000),
              })
              if (!resp.ok) continue
              const text = await resp.text()

              const itemMatches = text.matchAll(/<item>([\s\S]*?)<\/item>/g)
              let count = 0
              for (const match of itemMatches) {
                if (count >= 5) break
                const block = match[1]
                const title = block.match(/<title>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?<\/title>/)?.[1]?.trim()
                const link = block.match(/<link>(.*?)<\/link>/)?.[1]?.trim()
                const pubDate = block.match(/<pubDate>(.*?)<\/pubDate>/)?.[1]?.trim()
                if (title) {
                  results.push({
                    title: title.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"'),
                    source: feed.source,
                    link: link ?? '#',
                    pubDate: pubDate ?? new Date().toUTCString(),
                  })
                  count++
                }
              }
            } catch {
              // skip failed feeds
            }
          }

          if (results.length === 0) {
            return Response.json({ articles: getFallbackNews() })
          }

          return Response.json({ articles: results.slice(0, 10) })
        } catch {
          return Response.json({ articles: getFallbackNews() })
        }
      },
    },
  },
})

function getFallbackNews() {
  return [
    { title: 'GLOBAL MARKETS SHOW RESILIENCE AMID VOLATILITY', source: 'GRID NEWS', link: '#', pubDate: new Date().toUTCString() },
    { title: 'TECH SECTOR LEADS RECOVERY IN AFTERNOON TRADING', source: 'GRID NEWS', link: '#', pubDate: new Date().toUTCString() },
    { title: 'CENTRAL BANKS SIGNAL POLICY SHIFT ON INTEREST RATES', source: 'GRID NEWS', link: '#', pubDate: new Date().toUTCString() },
    { title: 'ENERGY PRICES STABILIZE AFTER WEEKS OF TURBULENCE', source: 'GRID NEWS', link: '#', pubDate: new Date().toUTCString() },
    { title: 'NEW AI DEVELOPMENTS RESHAPE ENTERPRISE COMPUTING', source: 'GRID NEWS', link: '#', pubDate: new Date().toUTCString() },
  ]
}
