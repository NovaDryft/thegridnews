import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/api/weather')({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url)
        const lat = url.searchParams.get('lat') ?? '27.2939'
        const lon = url.searchParams.get('lon') ?? '-80.3503'
        const city = url.searchParams.get('city') ?? 'Port Saint Lucie'

        try {
          const resp = await fetch(
            `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code,apparent_temperature&temperature_unit=fahrenheit&wind_speed_unit=mph&timezone=auto`
          )
          if (!resp.ok) throw new Error('Weather API failed')
          const data = await resp.json()
          const current = data.current

          const weatherCodes: Record<number, string> = {
            0: 'CLEAR SKY', 1: 'MAINLY CLEAR', 2: 'PARTLY CLOUDY', 3: 'OVERCAST',
            45: 'FOGGY', 48: 'RIME FOG', 51: 'LIGHT DRIZZLE', 53: 'DRIZZLE',
            55: 'DENSE DRIZZLE', 61: 'SLIGHT RAIN', 63: 'RAIN', 65: 'HEAVY RAIN',
            71: 'LIGHT SNOW', 73: 'SNOW', 75: 'HEAVY SNOW', 77: 'SNOW GRAINS',
            80: 'RAIN SHOWERS', 81: 'SHOWERS', 82: 'HEAVY SHOWERS',
            85: 'SNOW SHOWERS', 86: 'HEAVY SNOW SHOWERS', 95: 'THUNDERSTORM',
            96: 'THUNDERSTORM + HAIL', 99: 'HEAVY THUNDERSTORM'
          }

          return Response.json({
            city,
            temperature: Math.round(current.temperature_2m),
            feelsLike: Math.round(current.apparent_temperature),
            humidity: current.relative_humidity_2m,
            windSpeed: Math.round(current.wind_speed_10m),
            condition: weatherCodes[current.weather_code] ?? 'UNKNOWN',
            code: current.weather_code,
            timestamp: current.time,
          })
        } catch (err) {
          return Response.json({ error: 'Failed to fetch weather data' }, { status: 500 })
        }
      },
    },
  },
})
