import { createFileRoute } from '@tanstack/react-router'
import { useEffect, useRef, useState, useCallback } from 'react'

export const Route = createFileRoute('/')({
  component: TheGrid,
})

// ── Types ──────────────────────────────────────────────────────────────────────

interface WeatherData {
  city: string
  temperature: number
  feelsLike: number
  humidity: number
  windSpeed: number
  condition: string
  code: number
  error?: string
}

interface NewsArticle {
  title: string
  source: string
  link: string
  pubDate: string
}

interface StockItem {
  symbol: string
  price: number
  change: number
  changePct: number
  currency: string
  volume: number
}

// ── Matrix Rain Canvas ─────────────────────────────────────────────────────────

function MatrixRain() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const resize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }
    resize()
    window.addEventListener('resize', resize)

    const chars = 'ｦｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ<>[]{}|/'
    const fontSize = 14
    let columns = Math.floor(canvas.width / fontSize)
    const drops: number[] = Array(columns).fill(1)

    const draw = () => {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.05)'
      ctx.fillRect(0, 0, canvas.width, canvas.height)
      ctx.font = `${fontSize}px monospace`

      columns = Math.floor(canvas.width / fontSize)
      while (drops.length < columns) drops.push(1)

      for (let i = 0; i < columns; i++) {
        const char = chars[Math.floor(Math.random() * chars.length)]
        const brightness = Math.random()
        if (brightness > 0.95) {
          ctx.fillStyle = '#ffffff'
        } else if (brightness > 0.8) {
          ctx.fillStyle = '#00ff41'
        } else {
          ctx.fillStyle = '#003b00'
        }
        ctx.fillText(char, i * fontSize, drops[i] * fontSize)
        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
          drops[i] = 0
        }
        drops[i]++
      }
    }

    const interval = setInterval(draw, 50)
    return () => {
      clearInterval(interval)
      window.removeEventListener('resize', resize)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      style={{ position: 'fixed', top: 0, left: 0, zIndex: 0, opacity: 0.25, pointerEvents: 'none' }}
    />
  )
}

// ── Stock Ticker ───────────────────────────────────────────────────────────────

function StockTicker({ stocks }: { stocks: StockItem[] }) {
  if (stocks.length === 0) return <div className="ticker-wrap"><div className="ticker-loading">ACCESSING MARKET DATA...</div></div>
  return (
    <div className="ticker-wrap">
      <div className="ticker-label">LIVE MARKETS</div>
      <div className="ticker-track">
        {[...stocks, ...stocks].map((s, i) => (
          <span key={i} className="ticker-item">
            <span className="ticker-sym">{s.symbol}</span>
            <span className="ticker-price">
              ${s.price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className={s.change >= 0 ? 'ticker-up' : 'ticker-down'}>
              {s.change >= 0 ? '▲' : '▼'}{Math.abs(s.changePct).toFixed(2)}%
            </span>
            <span className="ticker-sep">◆</span>
          </span>
        ))}
      </div>
    </div>
  )
}

// ── Weather Widget ─────────────────────────────────────────────────────────────

function weatherIcon(code: number) {
  if (code === 0 || code === 1) return '☀'
  if (code === 2) return '⛅'
  if (code === 3) return '☁'
  if (code >= 45 && code <= 48) return '≋'
  if (code >= 51 && code <= 67) return '⛆'
  if (code >= 71 && code <= 77) return '❄'
  if (code >= 80 && code <= 82) return '⛈'
  if (code >= 85 && code <= 86) return '❆'
  if (code >= 95) return '⚡'
  return '◈'
}

function WeatherWidget({ data, loading }: { data: WeatherData | null; loading: boolean }) {
  return (
    <div className="panel">
      <div className="panel-header">
        <span className="panel-icon">◉</span>
        ATMOSPHERIC CONDITIONS
        <span className="panel-badge blink">LIVE</span>
      </div>
      {loading && !data ? (
        <div className="panel-loading">
          <span className="loading-dots">SCANNING ATMOSPHERE</span>
        </div>
      ) : data?.error ? (
        <div className="panel-error">◈ SIGNAL LOST — RECONNECTING</div>
      ) : data ? (
        <div className="weather-body">
          <div className="weather-main">
            <div className="weather-icon">{weatherIcon(data.code)}</div>
            <div className="weather-info">
              <div className="weather-temp">{data.temperature}<span className="weather-unit">°F</span></div>
              <div className="weather-condition">{data.condition}</div>
              <div className="weather-city">◈ {data.city}</div>
            </div>
          </div>
          <div className="weather-stats">
            <div className="wstat">
              <div className="wstat-label">FEELS LIKE</div>
              <div className="wstat-value">{data.feelsLike}°F</div>
            </div>
            <div className="wstat">
              <div className="wstat-label">HUMIDITY</div>
              <div className="wstat-value">{data.humidity}%</div>
            </div>
            <div className="wstat">
              <div className="wstat-label">WIND SPEED</div>
              <div className="wstat-value">{data.windSpeed} MPH</div>
            </div>
            <div className="wstat">
              <div className="wstat-label">NODE STATUS</div>
              <div className="wstat-value online">ONLINE</div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  )
}

// ── News Widget ────────────────────────────────────────────────────────────────

function NewsWidget({ articles, loading }: { articles: NewsArticle[]; loading: boolean }) {
  const formatTime = (d: string) => {
    try { return new Date(d).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }) }
    catch { return '--:--' }
  }

  return (
    <div className="panel panel-news">
      <div className="panel-header">
        <span className="panel-icon">◈</span>
        GLOBAL INTEL FEED
        <span className="panel-badge blink">LIVE</span>
      </div>
      {loading && articles.length === 0 ? (
        <div className="panel-loading"><span className="loading-dots">DECRYPTING TRANSMISSIONS</span></div>
      ) : (
        <ul className="news-list">
          {articles.slice(0, 9).map((a, i) => (
            <li key={i} className="news-item">
              <div className="news-meta">
                <span className="news-idx">[{String(i + 1).padStart(2, '0')}]</span>
                <span className="news-src">{a.source}</span>
                <span className="news-time">{formatTime(a.pubDate)}</span>
              </div>
              <div className="news-title">{a.title.toUpperCase()}</div>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

// ── Stocks Widget ──────────────────────────────────────────────────────────────

function fmtVol(v: number) {
  if (v >= 1_000_000_000) return `${(v / 1_000_000_000).toFixed(1)}B`
  if (v >= 1_000_000) return `${(v / 1_000_000).toFixed(1)}M`
  if (v >= 1_000) return `${(v / 1_000).toFixed(0)}K`
  return v ? String(v) : 'N/A'
}

function StocksWidget({ stocks, loading }: { stocks: StockItem[]; loading: boolean }) {
  return (
    <div className="panel">
      <div className="panel-header">
        <span className="panel-icon">◆</span>
        MARKET MATRIX
        <span className="panel-badge blink">LIVE</span>
      </div>
      {loading && stocks.length === 0 ? (
        <div className="panel-loading"><span className="loading-dots">ACCESSING MARKET DATA</span></div>
      ) : (
        <div className="stocks-wrap">
          <div className="stocks-thead">
            <span>SYMBOL</span>
            <span>PRICE (USD)</span>
            <span>CHANGE</span>
            <span>VOLUME</span>
          </div>
          <div className="stocks-body">
            {stocks.map((s) => (
              <div key={s.symbol} className={`srow ${s.change >= 0 ? 'srow-up' : 'srow-down'}`}>
                <span className="srow-sym">{s.symbol}</span>
                <span className="srow-price">
                  {s.price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
                <span className={`srow-chg ${s.change >= 0 ? 'up' : 'down'}`}>
                  {s.change >= 0 ? '▲ +' : '▼ '}{s.changePct.toFixed(2)}%
                </span>
                <span className="srow-vol">{fmtVol(s.volume)}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ── Status Bar ─────────────────────────────────────────────────────────────────

function StatusBar({ countdown, lastUpdate }: { countdown: number; lastUpdate: string }) {
  const [time, setTime] = useState(new Date())
  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(t)
  }, [])

  return (
    <footer className="status-bar">
      <span className="status-dot blink">◉</span>
      <span className="status-seg">SYSTEM ONLINE</span>
      <span className="status-pipe">│</span>
      <span className="status-seg">{time.toLocaleTimeString('en-US', { hour12: false })}</span>
      <span className="status-pipe">│</span>
      <span className="status-seg">REFRESH <span className="countdown">{countdown}s</span></span>
      <span className="status-pipe">│</span>
      <span className="status-seg">UPDATED {lastUpdate || '—'}</span>
      <span className="status-right">THE GRID v1.0 // ACCESS_LEVEL: OMEGA</span>
    </footer>
  )
}

// ── Main ───────────────────────────────────────────────────────────────────────

function TheGrid() {
  const [weather, setWeather] = useState<WeatherData | null>(null)
  const [news, setNews] = useState<NewsArticle[]>([])
  const [stocks, setStocks] = useState<StockItem[]>([])
  const [loadingWeather, setLoadingWeather] = useState(true)
  const [loadingNews, setLoadingNews] = useState(true)
  const [loadingStocks, setLoadingStocks] = useState(true)
  const [countdown, setCountdown] = useState(10)
  const [lastUpdate, setLastUpdate] = useState('')

  const fetchAll = useCallback(async () => {
    setLoadingWeather(true)
    setLoadingStocks(true)

    const [w, n, s] = await Promise.allSettled([
      fetch('/api/weather').then(r => r.json()),
      fetch('/api/news').then(r => r.json()),
      fetch('/api/stocks').then(r => r.json()),
    ])

    if (w.status === 'fulfilled') setWeather(w.value)
    setLoadingWeather(false)
    if (n.status === 'fulfilled') setNews(n.value.articles ?? [])
    setLoadingNews(false)
    if (s.status === 'fulfilled') setStocks(s.value.stocks ?? [])
    setLoadingStocks(false)

    setLastUpdate(new Date().toLocaleTimeString('en-US', { hour12: false }))
    setCountdown(10)
  }, [])

  useEffect(() => { fetchAll() }, [fetchAll])

  useEffect(() => {
    const tick = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) { fetchAll(); return 10 }
        return prev - 1
      })
    }, 1000)
    return () => clearInterval(tick)
  }, [fetchAll])

  return (
    <>
      <MatrixRain />
      <div className="grid-app">
        <header className="grid-header">
          <div className="hdr-brand">
            <span className="hdr-bracket">[</span>
            <span className="hdr-title">THE GRID</span>
            <span className="hdr-bracket">]</span>
          </div>
          <div className="hdr-sub">REAL-TIME INTELLIGENCE DASHBOARD</div>
          <div className="hdr-right">ACCESS_LEVEL: OMEGA</div>
        </header>

        <StockTicker stocks={stocks} />

        <main className="grid-main">
          <WeatherWidget data={weather} loading={loadingWeather} />
          <StocksWidget stocks={stocks} loading={loadingStocks} />
          <NewsWidget articles={news} loading={loadingNews} />
        </main>

        <StatusBar countdown={countdown} lastUpdate={lastUpdate} />
      </div>
    </>
  )
}
